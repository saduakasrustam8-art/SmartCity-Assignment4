// JUnit-style pseudocode (user may adapt to their environment)
// Add proper imports and a test runner in real environment
public class SimpleTests {
    // Test Tarjan on simple graph
    public void testSCCSimple() {
        // Graph: 0->1,1->2,2->0, 3->4
    }
}