import graph.scc.TarjanSCC;
import graph.scc.Condensation;
import graph.topo.KahnTopologicalSort;
import graph.dagsp.DAGShortestPath;
import java.util.*;
import java.nio.file.*;
import java.io.IOException;

/**
 * Simple runner: loads a JSON dataset from /data, runs SCC, condensation, topo, and DAG-SP.
 * This is a minimal runner intended for demonstration.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        String dataset = (args.length>0)? args[0] : "data/data_small_1.json";
        System.out.println("Loading dataset: " + dataset);
        Map<String, List<TarjanSCC.Edge>> graph = Utils.loadJsonGraph(dataset);
        TarjanSCC tarjan = new TarjanSCC(graph);
        TarjanSCC.Result sres = tarjan.run();
        System.out.println("SCC count: " + sres.components.size());
        for (int i=0;i<sres.components.size();i++) {
            System.out.println("Component " + i + ": " + sres.components.get(i));
        }
        Condensation.CondensationResult cres = Condensation.build(graph, sres.components);
        System.out.println("Condensation DAG size: " + cres.dagAdj.size());
        KahnTopologicalSort.Result tres = KahnTopologicalSort.sort(cres.dagAdj);
        if (!tres.isDAG) System.out.println("Warning: condensation is not DAG!");
        System.out.println("Topo order of components: " + tres.order);
        // Build a topological order of original nodes by expanding components in order
        List<String> topoNodes = new ArrayList<>();
        for (Integer compId: tres.order) {
            topoNodes.addAll(sres.components.get(compId));
        }
        // Run DAG shortest path on original graph (using edges weights)
        List<String> topoForOriginal = topoNodes; // approximation (works if condensation topo expanded)
        DAGShortestPath.Result dres = DAGShortestPath.shortestPath(topoForOriginal, graph, topoForOriginal.get(0));
        System.out.println("Sample distances from source " + topoForOriginal.get(0) + ":");
        dres.dist.forEach((k,v)-> System.out.println(k + " -> " + v));
    }
}