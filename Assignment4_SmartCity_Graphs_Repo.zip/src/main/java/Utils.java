import java.nio.file.*;
import java.util.*;
import org.json.*;

/**
 * Minimal JSON loader for graphs. Expects files in /data with nodes and edges.
 * Uses org.json library classes. For simplicity, a small JSON parser can be used; here we
 * include a naive parser assuming the org.json classes are available.
 */
public class Utils {
    public static Map<String, List<graph.scc.TarjanSCC.Edge>> loadJsonGraph(String path) throws Exception {
        String s = new String(Files.readAllBytes(Paths.get(path)));
        JSONObject obj = new JSONObject(s);
        JSONArray nodes = obj.getJSONArray("nodes");
        JSONArray edges = obj.getJSONArray("edges");
        Map<String, List<graph.scc.TarjanSCC.Edge>> graph = new LinkedHashMap<>();
        for (int i=0;i<nodes.length();i++) {
            graph.put(nodes.getString(i), new ArrayList<>());
        }
        for (int i=0;i<edges.length();i++) {
            JSONObject e = edges.getJSONObject(i);
            String from = e.getString("from");
            String to = e.getString("to");
            int w = e.getInt("weight");
            graph.get(from).add(new graph.scc.TarjanSCC.Edge(from,to,w));
        }
        return graph;
    }
}