package graph.dagsp;

import java.util.*;
/**
 * DAG shortest paths (edge weights) using topological order.
 * Also longest path via DP.
 */
public class DAGShortestPath {
    public static class Result {
        public final Map<String, Integer> dist; // distance from source
        public final Map<String, String> parent;
        public Result(Map<String,Integer> dist, Map<String,String> parent) {
            this.dist = dist; this.parent = parent;
        }
    }

    // topoOrder are vertices in topological order (as strings)
    public static Result shortestPath(List<String> topoOrder, Map<String, List<Edge>> adj, String source) {
        final int INF = Integer.MAX_VALUE / 4;
        Map<String,Integer> dist = new HashMap<>();
        Map<String,String> parent = new HashMap<>();
        for (String v: topoOrder) dist.put(v, INF);
        dist.put(source, 0);
        // map index for quick order lookup
        Map<String,Integer> idx = new HashMap<>();
        for (int i=0;i<topoOrder.size();i++) idx.put(topoOrder.get(i), i);

        for (String u: topoOrder) {
            if (dist.get(u) == INF) continue;
            for (Edge e: adj.getOrDefault(u, Collections.emptyList())) {
                if (dist.get(e.to) > dist.get(u) + e.weight) {
                    dist.put(e.to, dist.get(u) + e.weight);
                    parent.put(e.to, u);
                }
            }
        }
        return new Result(dist, parent);
    }

    public static List<String> reconstructPath(Map<String,String> parent, String target) {
        LinkedList<String> path = new LinkedList<>();
        String cur = target;
        while (cur != null) {
            path.addFirst(cur);
            cur = parent.get(cur);
        }
        return path;
    }

    // Longest path on DAG using DP (weights can be negative of shortest if desired)
    public static Map<String, Integer> longestPath(List<String> topoOrder, Map<String, List<Edge>> adj, String source) {
        final int NEG_INF = Integer.MIN_VALUE / 4;
        Map<String,Integer> best = new HashMap<>();
        for (String v: topoOrder) best.put(v, NEG_INF);
        best.put(source, 0);
        for (String u: topoOrder) {
            if (best.get(u) == NEG_INF) continue;
            for (Edge e: adj.getOrDefault(u, Collections.emptyList())) {
                if (best.get(e.to) < best.get(u) + e.weight) {
                    best.put(e.to, best.get(u) + e.weight);
                }
            }
        }
        return best;
    }

    public static class Edge {
        public final String from;
        public final String to;
        public final int weight;
        public Edge(String from, String to, int weight) {
            this.from = from; this.to = to; this.weight = weight;
        }
    }
}