package graph.topo;

import java.util.*;
/**
 * Kahn's algorithm for topological sort. Also counts pushes/pops.
 */
public class KahnTopologicalSort {
    public static Result sort(Map<Integer, List<Integer>> adj) {
        Map<Integer,Integer> indeg = new HashMap<>();
        for (Integer u: adj.keySet()) indeg.put(u,0);
        for (Map.Entry<Integer,List<Integer>> e: adj.entrySet()) {
            for (Integer v: e.getValue()) indeg.put(v, indeg.getOrDefault(v,0)+1);
        }
        Deque<Integer> q = new ArrayDeque<>();
        for (Map.Entry<Integer,Integer> e: indeg.entrySet()) {
            if (e.getValue()==0) q.add(e.getKey());
        }
        List<Integer> order = new ArrayList<>();
        long pushes=0, pops=0;
        while(!q.isEmpty()) {
            int u = q.removeFirst();
            pops++;
            order.add(u);
            for (Integer v: adj.getOrDefault(u, Collections.emptyList())) {
                indeg.put(v, indeg.get(v)-1);
                if (indeg.get(v)==0) {
                    q.add(v);
                    pushes++;
                }
            }
        }
        boolean isDAG = order.size() == adj.size();
        return new Result(order, pushes, pops, isDAG);
    }
    public static class Result {
        public final List<Integer> order;
        public final long pushes;
        public final long pops;
        public final boolean isDAG;
        public Result(List<Integer> order, long pushes, long pops, boolean isDAG) {
            this.order = order; this.pushes = pushes; this.pops = pops; this.isDAG = isDAG;
        }
    }
}