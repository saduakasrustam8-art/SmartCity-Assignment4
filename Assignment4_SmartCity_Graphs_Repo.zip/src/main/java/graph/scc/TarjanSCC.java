package graph.scc;

import java.util.*;

/**
 * Tarjan's strongly connected components algorithm.
 * Returns list of components (each component is a list of vertex ids as strings).
 */
public class TarjanSCC {
    private final Map<String, List<Edge>> graph;
    private final Map<String, Integer> indexMap = new HashMap<>();
    private final Map<String, Integer> lowlink = new HashMap<>();
    private final Deque<String> stack = new ArrayDeque<>();
    private final Set<String> onStack = new HashSet<>();
    private final List<List<String>> components = new ArrayList<>();
    private int index = 0;
    private long edgeTraversals = 0;
    public TarjanSCC(Map<String, List<Edge>> graph) {
        this.graph = graph;
    }
    public Result run() {
        for (String v : graph.keySet()) {
            if (!indexMap.containsKey(v)) {
                strongConnect(v);
            }
        }
        return new Result(components, edgeTraversals);
    }
    private void strongConnect(String v) {
        indexMap.put(v, index);
        lowlink.put(v, index);
        index++;
        stack.push(v);
        onStack.add(v);

        for (Edge e : graph.getOrDefault(v, Collections.emptyList())) {
            edgeTraversals++;
            String w = e.to;
            if (!indexMap.containsKey(w)) {
                strongConnect(w);
                lowlink.put(v, Math.min(lowlink.get(v), lowlink.get(w)));
            } else if (onStack.contains(w)) {
                lowlink.put(v, Math.min(lowlink.get(v), indexMap.get(w)));
            }
        }
        if (lowlink.get(v).equals(indexMap.get(v))) {
            List<String> comp = new ArrayList<>();
            String w;
            do {
                w = stack.pop();
                onStack.remove(w);
                comp.add(w);
            } while (!w.equals(v));
            components.add(comp);
        }
    }

    public static class Edge {
        public final String from;
        public final String to;
        public final int weight;
        public Edge(String from, String to, int weight) {
            this.from = from; this.to = to; this.weight = weight;
        }
    }

    public static class Result {
        public final List<List<String>> components;
        public final long edgeTraversals;
        public Result(List<List<String>> components, long edgeTraversals) {
            this.components = components; this.edgeTraversals = edgeTraversals;
        }
    }
}