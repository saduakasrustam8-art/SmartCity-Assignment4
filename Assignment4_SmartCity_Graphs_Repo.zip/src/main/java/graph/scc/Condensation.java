package graph.scc;

import java.util.*;

/**
 * Build condensation DAG from original graph and SCC components.
 * Component ids are integers (0..k-1), mapping provided via compMap.
 */
public class Condensation {
    public static CondensationResult build(Map<String, List<TarjanSCC.Edge>> graph, List<List<String>> comps) {
        Map<String,Integer> compMap = new HashMap<>();
        for (int i=0;i<comps.size();i++) {
            for (String v: comps.get(i)) compMap.put(v,i);
        }
        Map<Integer, Set<Integer>> dag = new HashMap<>();
        for (String u: graph.keySet()) {
            int cu = compMap.get(u);
            for (TarjanSCC.Edge e: graph.getOrDefault(u, Collections.emptyList())) {
                int cv = compMap.get(e.to);
                if (cu != cv) {
                    dag.computeIfAbsent(cu, k->new HashSet<>()).add(cv);
                }
            }
        }
        // convert to adjacency list with weights ignored (or could be aggregated)
        Map<Integer, List<Integer>> adj = new HashMap<>();
        for (Map.Entry<Integer, Set<Integer>> entry: dag.entrySet()) {
            adj.put(entry.getKey(), new ArrayList<>(entry.getValue()));
        }
        // ensure all components appear
        for (int i=0;i<comps.size();i++) adj.putIfAbsent(i, new ArrayList<>());
        return new CondensationResult(adj, compMap);
    }

    public static class CondensationResult {
        public final Map<Integer, List<Integer>> dagAdj;
        public final Map<String,Integer> compMap;
        public CondensationResult(Map<Integer, List<Integer>> dagAdj, Map<String,Integer> compMap) {
            this.dagAdj = dagAdj; this.compMap = compMap;
        }
    }
}