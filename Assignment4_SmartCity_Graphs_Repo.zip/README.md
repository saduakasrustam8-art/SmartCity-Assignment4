# Smart City / Smart Campus Scheduling — Assignment 4

**Contents:** implementation of SCC (Tarjan), condensation DAG, topological ordering (Kahn), single-source shortest paths and longest path on DAG; dataset generators; JUnit tests; metrics instrumentation.

**Structure:**
```
/src/main/java/graph/scc  - TarjanSCC + Condensation builder
/src/main/java/graph/topo - KahnTopologicalSort
/src/main/java/graph/dagsp - DAG shortest/longest path utilities
/src/test/java - JUnit tests
/data - 9 datasets (small, medium, large)
README.md - this file (report & analysis)
```

## Report / Analysis (summary)

### Datasets
Nine datasets were generated under `/data/`:
- 3 small (n=6..10), 1-2 cycles each
- 3 medium (n=10..20), mixed structures
- 3 large (n=20..50), performance-oriented

See `/data/README_datasets.md` for sizes and description.

### Algorithms implemented
1. **TarjanSCC** (graph.scc.TarjanSCC) — linear-time SCC detection using a single DFS pass (O(n+m)). Produces list of components (each component is a list of vertices) and component id map.
2. **Condensation** (graph.scc.Condensation) — builds DAG where nodes are SCCs and edges reflect inter-component edges.
3. **KahnTopologicalSort** (graph.topo.KahnTopologicalSort) — Kahn's algorithm with operation counters; returns topo order of condensation DAG and derived order of original vertices (SCC-compressed).
4. **DAG shortest/longest** (graph.dagsp.DAGShortestPath) — single-source shortest paths on DAG using topological order (O(n+m)). Longest path computed via DP on topo order (supports node durations or edge weights as chosen). See README for chosen model.

### Chosen weight model
For this assignment we use **edge weights** (integer). The datasets include `edges` with `weight` field. Shortest path is computed on edge weights. Longest path uses DP to maximize total weight (critical path).

### Instrumentation & Metrics
A simple `Metrics` class records operation counts and time via `System.nanoTime()`; counters include DFS visits, edge traversals, pushes/pops (Kahn), and relaxations (DAG-SP). Each algorithm returns metrics alongside results.

### How to build & run
1. Clone repository locally.
2. Build with Maven or javac (project is plain Java source). Example:
```bash
javac -d out src/main/java/graph/**/*.java src/main/java/*.java
java -cp out graph.Main
```
JUnit tests under `src/test/java` (if using Maven, add pom and run `mvn test`).

### Results (summary)
See `README.md` and `report.pdf` inside repo for result tables and analysis. The implementation is tested on provided datasets; timing scales approximately linearly with edges for SCC and DAG-SP as expected; dense graphs show larger absolute times due to more edges.

---
**Note:** This repository is prepared for upload to GitHub. After pushing, submit the repository link in Moodle as required.
