Datasets for Assignment 4 (JSON graph format)
Each dataset file named data_<size>_<idx>.json contains:
{
  "nodes": [ "0", "1", "2", ... ],
  "edges": [ {"from":"0","to":"1","weight":5}, ... ]
}
Three sizes: small (6-10), medium (10-20), large (20-50).
